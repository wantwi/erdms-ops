export const  GetAssignedActivityEndpoint = `Job/JobActivities/Officer`
export const GetRecentActivities = ""