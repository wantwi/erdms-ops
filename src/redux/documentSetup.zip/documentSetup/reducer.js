import { DocumentSetupActionTypes } from "./actions";

const { GET_ALL_DOCUMENT,ADD_NEW_DOCUMENT,SHOW_MODAL } = DocumentSetupActionTypes;

const initialState = {
  documents: [],
  showModal:false
};

const DocumentSetupReducer = function(state = initialState, action) {
  switch (action.type) {
    case SHOW_MODAL:
      {
        return {
          ...state,
          showModal: !state.showModal
        };
      }
    case GET_ALL_DOCUMENT:
      {
        return {
          ...state,
          documents: [...action.payload],
          showModal:false
        };
      }
      case ADD_NEW_DOCUMENT:

        {
          return {
            ...state,
            documents: [...action.payload],
            showModal:false
          };
        }

    default: {
      return {
        ...state,
      };
    }
  }
};

export default DocumentSetupReducer;
