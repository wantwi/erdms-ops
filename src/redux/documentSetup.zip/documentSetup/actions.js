// import axios from "axios";
export const DocumentSetupActionTypes = {
  GET_ALL_DOCUMENT: "GET_ALL_DOCUMENT",
  ADD_NEW_DOCUMENT: "ADD_NEW_DOCUMENT",
  SHOW_MODAL: "SHOW_MODAL",
};

const {
  GET_ALL_DOCUMENT,
  ADD_NEW_DOCUMENT,
  SHOW_MODAL,
} = DocumentSetupActionTypes;

let data = [];

export const toggleModal = () => async (dispatch) => {
  try {
    dispatch({
      type: SHOW_MODAL,
    });
  } catch (error) {
    console.log({ error });
  }
};

export const getAllDocuments = () => async (dispatch) => {
  try {
    dispatch({
      type: GET_ALL_DOCUMENT,
      payload: data,
    });
  } catch (error) {
    console.log({ error });
  }
};

export const addNewDocument = (newdata) => async (dispatch) => {
  try {
    data.push(newdata);
    dispatch({
      type: ADD_NEW_DOCUMENT,
      payload: data,
    });
  } catch (error) {
    console.log({ error });
  }
};
